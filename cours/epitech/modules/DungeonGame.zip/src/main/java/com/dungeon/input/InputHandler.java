// ========== InputHandler.java ==========
package com.dungeon.input;

/**
 * Interface for input handling.
 * Demonstrates abstraction and allows for different input methods.
 */
public interface InputHandler {
    /**
     * Handles input processing.
     */
    void handleInput();
}