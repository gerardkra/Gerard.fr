// ========== Direction.java ==========
package com.dungeon.physics;

/**
 * Enum representing four cardinal directions.
 */
public enum Direction {
    /** Upward direction */
    UP,
    
    /** Downward direction */
    DOWN,
    
    /** Left direction */
    LEFT,
    
    /** Right direction */
    RIGHT
}
