#!/bin/bash

# Script pour télécharger les fichiers audio pour Dungeon Escape
# Tous les fichiers sont sous licence Creative Commons ou domaine public

echo "🎵 Téléchargement des fichiers audio pour Dungeon Escape..."

# Créer la structure de dossiers
mkdir -p src/main/resources/sounds/music
mkdir -p src/main/resources/sounds/effects

echo "📁 Dossiers créés"

# ============================================
# MUSIQUES (Format MP3)
# ============================================

echo "🎶 Téléchargement des musiques..."

# Musique de menu - "Pixabay - Dark Fantasy Ambient"
curl -L "https://cdn.pixabay.com/download/audio/2024/04/23/audio_4e1c30a7dc.mp3?filename=dark-fantasy-ambient-dungeon-synth-185374.mp3" \
  -o "src/main/resources/sounds/music/menu.mp3"

# Musique de gameplay - "Pixabay - 8 Bit Dungeon"
curl -L "https://cdn.pixabay.com/download/audio/2024/10/17/audio_1e8fd73a53.mp3?filename=8-bit-dungeon-243082.mp3" \
  -o "src/main/resources/sounds/music/gameplay.mp3"

# Musique de victoire - "Pixabay - Epic Dungeon Beat"
curl -L "https://cdn.pixabay.com/download/audio/2024/10/17/audio_3a4cdb23e4.mp3?filename=epic-dungeon-beat-243084.mp3" \
  -o "src/main/resources/sounds/music/victory.mp3"

echo "✅ Musiques téléchargées"

# ============================================
# EFFETS SONORES (Format WAV)
# ============================================

echo "🔊 Téléchargement des effets sonores..."

# Son de collecte - "Coin Collect" de Freesound
curl -L "https://cdn.freesound.org/previews/320/320655_5260872-lq.mp3" \
  -o "src/main/resources/sounds/effects/collect.wav"

# Son de dégâts - "Damage Hit" de Freesound
curl -L "https://cdn.freesound.org/previews/458/458867_5674468-lq.mp3" \
  -o "src/main/resources/sounds/effects/damage.wav"

# Son de victoire courte - "Victory Sting" de Freesound
curl -L "https://cdn.freesound.org/previews/87/87042_1015240-lq.mp3" \
  -o "src/main/resources/sounds/effects/victory.wav"

# Son de game over - "Fail Sound" de Freesound
curl -L "https://cdn.freesound.org/previews/142/142608_2615119-lq.mp3" \
  -o "src/main/resources/sounds/effects/gameover.wav"

# Son de level up - "Level Up" de Freesound
curl -L "https://cdn.freesound.org/previews/270/270319_5123851-lq.mp3" \
  -o "src/main/resources/sounds/effects/levelup.wav"

# Son de clic - "Button Click" de Freesound
curl -L "https://cdn.freesound.org/previews/256/256116_4486188-lq.mp3" \
  -o "src/main/resources/sounds/effects/click.wav"

echo "✅ Effets sonores téléchargés"

# ============================================
# VÉRIFICATION
# ============================================

echo ""
echo "📊 Vérification des fichiers téléchargés:"
echo ""
echo "Musiques:"
ls -lh src/main/resources/sounds/music/
echo ""
echo "Effets sonores:"
ls -lh src/main/resources/sounds/effects/
echo ""
echo "✅ Téléchargement terminé!"
echo ""
echo "⚠️  IMPORTANT: Ces fichiers sont sous licences Creative Commons."
echo "    Vérifiez les attributions requises pour votre projet."
echo ""
echo "🎮 Vous pouvez maintenant lancer votre jeu avec le son!"