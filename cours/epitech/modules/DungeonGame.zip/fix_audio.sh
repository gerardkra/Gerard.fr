#!/bin/bash

echo "📦 Installation des polices avec support emoji..."

# Mise à jour des paquets
sudo apt update

# Installation des polices emoji et Unicode
echo "⬇️  Téléchargement des polices..."
sudo apt install -y \
    fonts-noto-color-emoji \
    fonts-noto-cjk \
    fonts-noto-cjk-extra \
    fonts-dejavu \
    fonts-liberation \
    fonts-symbola \
    ttf-ancient-fonts

# Configuration de fontconfig pour prioriser les emojis
echo "⚙️  Configuration de fontconfig..."
sudo tee /etc/fonts/local.conf << 'EOF' > /dev/null
<?xml version="1.0"?>
<!DOCTYPE fontconfig SYSTEM "fonts.dtd">
<fontconfig>
  <alias>
    <family>sans-serif</family>
    <prefer>
      <family>Noto Sans</family>
      <family>Noto Color Emoji</family>
      <family>Symbola</family>
    </prefer>
  </alias>
  <alias>
    <family>serif</family>
    <prefer>
      <family>Noto Serif</family>
      <family>Noto Color Emoji</family>
      <family>Symbola</family>
    </prefer>
  </alias>
  <alias>
    <family>monospace</family>
    <prefer>
      <family>Noto Mono</family>
      <family>Noto Color Emoji</family>
      <family>Symbola</family>
    </prefer>
  </alias>
</fontconfig>
EOF

# Rafraîchir le cache des polices
echo "🔄 Rafraîchissement du cache des polices..."
fc-cache -fv

# Vérifier l'installation
echo ""
echo "✅ Installation terminée!"
echo ""
echo "📊 Polices emoji installées:"
fc-list | grep -i emoji | head -5

echo ""
echo "🎮 Les emojis devraient maintenant s'afficher correctement!"
echo "   Relancez votre jeu: mvn javafx:run"
echo ""
echo "⚠️  Note: Si les emojis ne s'affichent toujours pas,"
echo "   fermez complètement votre terminal WSL et relancez-le."