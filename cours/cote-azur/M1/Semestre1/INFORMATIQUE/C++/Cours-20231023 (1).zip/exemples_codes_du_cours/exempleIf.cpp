#include <iostream>
using namespace std;

int main()
{
  int a;
    
  a = 0;
  if (a == 0)
    {
      cout << "a est nul" << endl;
    }
  else
    {
      cout << "a est non nul" << endl;
    }
  return 0;
}
