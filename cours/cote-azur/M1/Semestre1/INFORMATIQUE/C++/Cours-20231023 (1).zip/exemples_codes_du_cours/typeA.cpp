#include <iostream>
using namespace std;

int main()
{
  int a;               // On d�clare un entier a; on r�serve donc 4 octets en m�moire que l'on nomme 'a'
  unsigned int b;      // On d�clare un entier non sign� b, 4 octets sont aussi allou�s
  char c;              // On d�clare un caract�re 'c', un octet est r�serv�
  double reel1, reel2; // deux r�els sont d�clar�s et la place correspondante en m�moire est allou�e

  a = 0;       // On attribue � 'a' la valeur 0 -> jusqu'� maintenant, elle n'avait pas de valeur
  b = -1;      // On essaye de donner une valeur n�gative � b !
  c = 'a';     // 'a' est la notation pour le caract�re a.
  reel1 = 1e4; //  reel1 prend la valeur 10000
  reel2 = 0.0001;
  cout << "a : " << a << " " << endl
	    << "Interessant : "
	    << "b : " << b << endl    // HA ! - �a n'est pas -1!
	    << "c ; " << c << " " << endl;
  cout << reel1 << endl;
  cout << reel2 << endl;
}
