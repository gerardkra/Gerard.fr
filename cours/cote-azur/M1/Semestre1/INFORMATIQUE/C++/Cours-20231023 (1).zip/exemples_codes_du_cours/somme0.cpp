#include <iostream>
using namespace std;

//  D�claration de la fonction somme
double somme(double a, double b);

// Point d'entr�e de notre programme
int main()
{
  double a, b;
  cout << "Donnez deux reels" << endl;
  cin >> a >> b;
  cout << a << " + " << b << " = " << somme(a, b) << endl;
  return 0;
}

// d�finition de la fonction somme
double somme(double a, double b)
{
  return a+b;
}
