#include <iostream>
using namespace::std;
// = using namespace std;

int main(void) {  // = int main()
  int a=12, b=5;
  cout << "a = " << a
       << ", b = " << b << endl;
  cout << "a++ = " << a++
       << ", a = " << a << endl;
  cout << "++b = " << ++b
       << ", b = " << b << endl;
  return 0;
}
