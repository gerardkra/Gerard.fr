#ifndef __SOMME_HH__
#define __SOMME_HH__

/* D�claration de la fonction somme */

double somme (double a, double b);

#endif