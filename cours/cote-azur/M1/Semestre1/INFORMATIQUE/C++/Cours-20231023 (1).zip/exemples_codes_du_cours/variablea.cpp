#include <iostream>
using namespace std;

int main()
{
  int a;

  a = 0;
  cout << "a vaut " << a << endl;
  a = 5;
  cout << "a vaut � pr�sent: " << a << endl;
  cout << &a << endl;
}
