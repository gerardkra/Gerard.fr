# -*- coding: utf-8 -*-
"""
Created on Fri Oct 14 11:45:55 2022

@author: simon
"""
 


import numpy as np
import matplotlib.pyplot as plt


#I.1
#1. Programmation de la méthode d'Euler explicite

#%% a) Si on note $dt=(t_f-t_0)/(N-1)$ la longeur d'un pas de temps alors 
#  pour tout n,  y_{n+1}=y_n+dt(-ky_n + r)$

# Bonus : On peut reconnaitre une suite arithmético-géométrique, et on en déduit que
# $y_n=(1-k*dt)^n\left(y_0-\frac{r}{k}\right)+\frac{r}{k}$

#%% b)
def EulerExplicite(k,r,t0,tf,y0,N):
    y=np.zeros(N+1) # contiendra les y_n
    y[0]=y0
    t=np.linspace(t0,tf,N+1)
    dt=(tf-t0)/N # ou dt=t[1]-t[0] par exemple
    for i in range(0,N):
        y[i+1]=y[i]+dt*(-k*y[i]+r)
    return t,y

 #%%c et d) voir plus loin 
 
#%%  2 - Programmation de la méthode d'Euler implicite 

#%% a)    y_{n+1}=y_n+\Delta_t(-ky_{n+1} + r)$, c'est à dire $y_{n+1}=(y_n+r*dt)/(1+k*dt))

#%% b)

def EulerImplicite(k,r,t0,tf,y0,N):
    y=np.zeros(N+1) # contiendra les y_n
    y[0]=y0
    t=np.linspace(t0,tf,N+1)
    dt=(tf-t0)/N # ou dt=t[1]-t[0] par exemple
    for i in range(0,N):
        y[i+1]=(y[i]+dt*r)/(1+dt*k)
    return t,y

 
#%% Questions c) et d) : voir plus loins


#%%  3 - Programmation de la méthode de Crank-Nicolson


#%% a)    y_{n+1}=y_n+\Delta_t(-ky_{n+1} + r)$, c'est à dire $y_{n+1}=(y_n+r*dt)/(1+k*dt))

#%% b)

def Crank(k,r,t0,tf,y0,N):
    y=np.zeros(N+1) # contiendra les y_n
    y[0]=y0
    t=np.linspace(t0,tf,N+1)
    dt=(tf-t0)/N # ou dt=t[1]-t[0] par exemple
    for i in range(0,N):
        y[i+1]=(y[i]*(1-k*dt/2)+dt*r)/(1+k*dt/2)
    return t,y



#%% question c) pour les trois schémas 

#choisir un schéma
Schema=EulerExplicite  # pour la partie 1
#Schema=EulerImplicite  # pour la partie 2
#Schema=Crank  # pour la partie 3

 
def SolutionExacte(t,k,r,y0):
    y=(y0-r/k)*np.exp(-k*t)+r/k
    return y


k=150
r=0    
y0=1
t0=0
tf=1

i=1
for N in [50,70,90,160]:
    [temps,y]=Schema(k,r,t0,tf,y0,N) # les (t_n) et les (y_n) calculés par Euler explicite
    sol_exacte=SolutionExacte(temps,k,r,y0) # le vecteur contenant les y(t_n), donc la solution exacte aux temps t_n
    plt.subplot(2,2,i)
    i=i+1
    if Schema==EulerExplicite:
        lab="Euler exp"
    elif Schema==EulerImplicite:
        lab="Euler imp"
    elif Schema==Crank:
        lab="Crank-Nic"
    plt.plot(temps,y, 'red', linewidth=1, label=lab )
    plt.plot(temps,sol_exacte, 'blue', linewidth=1, label="Sol exacte" )
    plt.legend(loc=0)


#%% question d) pour les trois schémas 



Valeurs_N=np.arange(1000,1500,1)  
test_dt=1/(Valeurs_N);
Normeoo=np.zeros(len(Valeurs_N))
for i in range(len(Valeurs_N)):
    [tempsN,yN]=Schema(k,r,t0,tf,y0,Valeurs_N[i]);
    sol_exacteN=SolutionExacte(tempsN,k,r,y0);
    Normeoo[i]=np.max(np.abs(yN-sol_exacteN));

plt.loglog(test_dt,Normeoo, linewidth=1, label="Erreur_Max(N)" )
plt.xlabel('log(dt)', fontsize=14)
plt.ylabel('log(Erreur) ', fontsize=14)

ordreoo=np.polyfit(np.log(test_dt),np.log(Normeoo),1)[0] # le premier coef renvoyé est le coef du terme de degré 1 

print("ordre de convergence =", ordreoo)
#%% Partie théorique
 
#%% Questions c) et d) : Utiliser Schema=Crank dans le code de la question c) d'EulerExplicite
 



# On cherche à exprimer $(y_{n+1}-r/k)$ en fonction de $(y_{n}-r/k)$ pour le schéma d'Euler explicite
 
# Soit $(y_{0}-r/k)=\delta$. Alors $(y_{1}-r/k)=...=delta*(1-dt*k)

# Par récurrence immédiate, (y_{n}-r/k)=delta*(A-dt*k)^n
# Les résultats de la question b (oscillations non bornées, oscillations bornées, décroissance stricte)
# s'explique alors par la valeur de 1-dt*k (<-1 dans le premier cas, puis dans ]-1,0[, puis dans ]0,1[)


# Pour Euler implicite on a (y_n-r/k) qui converge vers r/k en décroissant, quelque soit dt
# Pour Crank-Nicolson on trouverait (y_n-r/k) 

 


