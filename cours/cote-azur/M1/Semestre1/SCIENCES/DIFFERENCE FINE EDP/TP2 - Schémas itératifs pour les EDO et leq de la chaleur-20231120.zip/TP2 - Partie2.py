# -*- coding: utf-8 -*-
"""
Created on Mon Nov 20 10:18:57 2023

@author: simon
"""

import matplotlib.pyplot as plt
from matplotlib import cm
import numpy as np


#from mpl_toolkits.mplot3d import Axes3D # Nécessaire sur les machines du petit Valrose


#%% Question 2.c


def ResolutionExp(N,M,mu, tf,L):
    T=np.linspace(0,tf,N+1)
    X=np.linspace(0,L,M+2)
    U=np.zeros((M+2,N+1))
    U[:,0]=np.sin(np.pi*X)
    dt=tf/N
    dx=L/(M+1)
    c=mu*dt/dx**2
    A=(1-2*c)*np.eye(M)
    B=c*np.eye(M,k=1)
    C=c*np.eye(M,k=-1)
    A=A+B+C
    V=U[1:M+1,0]
    for i in range(N):
        V=np.dot(A,V)
        U[1:M+1,i+1]=V
        #U[1:M+1,i+1]=U[1:M+1,i]+dt*mu*(U[:-2,i]-2*U[1:M+1,i]+U[2:,i])/dx**2
    return T, X, U


#%% A titre informatif, on peut aussi le faire avec un seul produit matriciel 
# comme dans le TP1. Dans le TP1 c'était le seul choix possible 
# Mais ici nos équations sont découplées (par blocs de taille M)
# Il est plus efficace (en nombre d'opérations et donc en temps de calcul)
# d'exploiter cette structure avec un le schéma itératif ci-dessus

def ResolutionExpBis(N,M,mu, tf,L):
    T=np.linspace(0,tf,N+1)
    X=np.linspace(0,L,M+2)
    U=np.zeros((M+2,N+1))
    U[:,0]=np.sin(np.pi*X)
    dt=tf/N
    dx=L/(M+1)
    c=mu*dt/dx**2
    F=np.zeros((N*M))
    for i in range(M):
        F[i]=c*(U[i,0]+U[i+2,0]-2*U[i+1,0])+U[i+1,0]
    A=np.eye(N*M)
    for i in range(M,N*M):
        A[i,i-M]=-1+2*c
        if (i)%M!=0 :
            A[i,i-M-1]=-c
        if (i+1)%M!=0:
            A[i,i-M+1]=-c

    u=np.zeros((N*M,1))
    u=np.linalg.solve(A,F)
    u=u.reshape(N,M).T
    U[1:-1,1:]=u
    return T,X,U


#%% Question d : Schéma Implicite en temps.
# On écrit le schéma de la même façon en se plaçant au temps (n+1) au lieu
# de se placer au temps n dans l'approximation de la dérivée seconde en espace
# on obtient une relation du type u_i^n= combinaison linéaire des u_j^(n+1), avec j=i, i-1 et i+1
# Sous forme matricielle, on a un schéma de la forme AU(n+1)=U(n) où U(n) est le vecteur des
#u_i^n
# On pourrait montrer que A est inversible et on a donc U(n+1)=inv(A)U(n)


def ResolutionImp(N,M,mu,tf,L):
    T=np.linspace(0,tf,N+1)
    X=np.linspace(0,L,M+2)
    U=np.zeros((M+2,N+1))
    U[:,0]=np.sin(np.pi*X)
    dt=tf/N
    dx=L/(M+1)
    c=mu*dt/dx**2
    A=(1+2*c)*np.eye(M)
    B=-c*np.eye(M,k=1)
    C=-c*np.eye(M,k=-1)
    A=A+B+C
    V=U[1:M+1,0]
    for i in range(N):
        V=np.linalg.solve(A,V)
        U[1:M+1,i+1]=V
    return T, X, U


 
# On ne constate pas de problèmes d'instabilité 
# (en fait on peut montrer que le schéma est stable pour tout choix de dt et dx)




#%% Crank-Nicolson
# On obtient cette fois une relation de la forme A2 U(n+1)=A1 U(n)

def Crank(N,M,mu,tf,L):
    T=np.linspace(0,tf,N+1)
    X=np.linspace(0,L,M+2)
    U=np.zeros((M+2,N+1))
    U[:,0]=np.sin(np.pi*X)
    dt=tf/N
    dx=L/(M+1)
    c=mu*dt/dx**2
    c=c/2 # le facteur /2
    A1=(1-2*c)*np.eye(M) # la matrice qui apparait devant U(n)
    B1=c*np.eye(M,k=1)
    C1=c*np.eye(M,k=-1)
    A1=A1+B1+C1
    A2=(1+2*c)*np.eye(M) # la matrice devant U(n+1)
    B2=-c*np.eye(M,k=1)
    C2=-c*np.eye(M,k=-1)
    A2=A2+B2+C2
    V=U[1:M+1,0]
    for i in range(N):
        V=np.linalg.solve(A2,np.dot(A1,V))
        U[1:M+1,i+1]=V
    return T, X, U

#%% Question 1.d

Schema=ResolutionExp #pour Euler explicite
#Schema=ResolutionImp # pour Euler implicite
#Schema=Crank # pour Crank Nicolson
tf=0.5
L=1
mu=1
T,X,U=Schema(110,10,mu,tf,L);
TT,XX=np.meshgrid(T,X)
fig, ax = plt.subplots(subplot_kw={"projection": "3d"})
surf = ax.plot_surface(TT, XX, U, cmap=cm.coolwarm,linewidth=0, antialiased=False)
ax.set_xlabel('t')
ax.set_ylabel('x')
ax.set_zlabel('u')


#%% Question 1.e
Schema=ResolutionExp #pour Euler explicite
#Schema=ResolutionImp # pour Euler implicite
#Schema=Crank # pour Crank Nicolson

T,X,U=Schema(50,10,mu,tf,L);
TT,XX=np.meshgrid(T,X)
fig, ax = plt.subplots(subplot_kw={"projection": "3d"})
surf = ax.plot_surface(TT, XX, U, cmap=cm.coolwarm,linewidth=0, antialiased=False)
ax.set_xlabel('t')
ax.set_ylabel('x')
ax.set_zlabel('u')
## Ces choix de N et M font tomber dt et dx en dehors de la zone de stabilité (condition CFL) du schéma
# REMARQUE : on aurait même pu prendre un maillage plus fin qu'en question 1.d, et pourtant avoir
# une solution numérique moins bonne ! Prendre par exemple M=30, N=300 :
# Dans ce cas le maillage est beaucoup plus fin, mais on a M**2>N, donc dt**2>dx**2/2 ==> instabilité


#%% Question 1.f
def solution(t,x):
    u=np.exp(-np.pi*np.pi*t)*np.sin(np.pi*x)
    return u

 
# Tracé de la solution exacte
# Uexac=solution(TT,XX)
# fig, ax = plt.subplots(subplot_kw={"projection": "3d"})
# surf = ax.plot_surface(TT, XX, Uexac, cmap=cm.coolwarm,linewidth=0, antialiased=False)
# ax.set_xlabel('t')
# ax.set_ylabel('x')
# ax.set_zlabel('u')

# La solution numérique est très proche de la solution exacte. Si on veut on peut regarder la différence
# On peut essayer d'augmenter M et N (tout en respectant la condition CFL, qui ici se traduit par N>=M**2)
T,X,U=Schema(30000,100,1,tf,L);   
TT,XX=np.meshgrid(T,X)
Uexac=solution(TT,XX)
fig, ax = plt.subplots(subplot_kw={"projection": "3d"})
surf = ax.plot_surface(TT, XX, U-Uexac, cmap=cm.coolwarm,linewidth=0, antialiased=False)
ax.set_xlabel('t')
ax.set_ylabel('x')
ax.set_zlabel('u')