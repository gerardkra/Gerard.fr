# -*- coding: utf-8 -*-
"""
Created on Sat Jan 13 16:03:41 2024

@author: otnie
"""

import numpy as np
import matplotlib.pyplot as plt


def distri_stat(P, mu, epsilon, n, damping_factor):
    current = mu
    conv = []
    ind = []
    print(p_i)
    for i in range(n):
        new_distri = (1-damping_factor)*np.dot(current, P) + damping_factor/10
        diff = np.linalg.norm(new_distri - current, 1)
        conv.append(diff)
        ind.append(i)
        print("t=" + str(i + 1) + " ===> ", new_distri)
        print("----------")
        if diff < epsilon:
            break
        current = new_distri
    return current, conv, ind

def plot_convergence(mu, ax, damping_factor):
    X, C, I = distri_stat(P, mu, 1e-3, 30, damping_factor)
    F = [(1 - damping_factor)**i for i in I]
    ax.plot(I, C, 'o', label='Ecart entre les distributions')
    ax.plot(I, F, linestyle='-', color='red', label='(1 - c)^n')
    ax.set_xlabel('Iterations')
    ax.set_ylabel('Ecart entre les distributions')
    ax.set_title(f'Convergence de l\'algorithme avec damping factor={damping_factor}')
    ax.grid(True)
    ax.legend()


P = np.array([[0, 1/4, 1/4, 1/4, 1/4, 0, 0, 0, 0, 0], 
              [1/2, 0, 1/2, 0, 0, 0, 0, 0, 0, 0],
              [1/2, 0, 0, 1/2, 0, 0, 0, 0, 0, 0], 
              [1/2, 1/2, 0, 0, 0, 0, 0, 0, 0, 0], 
              [0, 0, 0, 0, 0, 1/3, 1/3, 1/3, 0, 0], 
              [1/2, 0, 0, 0, 0, 0, 1/2, 0, 0, 0],
              [0, 0, 0, 0, 1, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 1/2, 0, 1/2, 0],
              [0, 0, 0, 1/4, 1/4, 0, 0, 0, 1/4, 1/4],
              [0, 0, 0, 0, 0, 0, 1/2, 0, 1/2, 0]])


mu1 = np.array([1, 0, 0, 0, 0, 0, 0, 0, 0, 0])
mu2 = np.array([0, 0, 0, 0, 1, 0, 0, 0, 0, 0])


fig, axs = plt.subplots(1, 2, figsize=(12, 4))


plot_convergence(mu1, axs[0], damping_factor=0.15)
axs[0].set_title('Initial Distribution: [1, 0, 0, 0, 0, 0, 0, 0, 0, 0]')


plot_convergence(mu2, axs[1], damping_factor=0.15)
axs[1].set_title('Initial Distribution: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0]')

plt.tight_layout()
plt.show()
