###Simulation de l'echantillon###

#on simule deux groupes. Le groupe 1 (label 0) selon une loi normale de parametre m1,sd1. Le deuxi�me selon une
#loi normale m2,sd2. "p" donne la proportion pour le nombre d'elements dans chaque groupe

Simulnor=function(Nobs=200,m1=-0.7,m2=0.7,sd1=1,sd2=1,nbdim=2,p=0.5){

	#taille du premier echantillon
	N1=rbinom(1,Nobs,p)

	#taille du deuxi�me echantillon
	N2=Nobs-N1

	#Simulation de X
    	X1=matrix(rnorm(nbdim*N1,m1,sd1),ncol=nbdim)
	X2=matrix(rnorm(nbdim*N2,m2,sd2),ncol=nbdim)
	X=rbind(X1,X2)

	#simulation du label
	Y1=rep(0,N1)
	Y2=rep(1,N2)
	Y=c(Y1,Y2)

	#concatenation
	cbind(X,Y)
}


XY=Simulnor()


#### graph des donnees ####
#mescol=c("red","blue")
#plot(XY[,1],XY[,2],col=mescol[XY[,ncol(XY)]+1])

#################
##### k-ppv #####
#################


###norme euclidienne### 

NormEucl=function(x){sqrt(sum(x^2))}

### Classification ###
knn=function(x,ech,k){
	Nbcol=ncol(ech)
	X=ech[,-Nbcol]
	label=ech[,Nbcol]
#Distances a x
	D=apply(X-matrix(rep(x,nrow(ech)),ncol=(Nbcol-1),byrow=TRUE),1,NormEucl) #une autre fa�on que d'utiliser les "transpose"
#on reordonne l'echantillon
	ech=ech[order(D),]	
#on r�cup�re les k premières coordonnees X
    X=ech[1:k,-ncol(ech)]
#on recup�re les k premiers label. le sort permet d'assurer qu'en cas d'égalité le label le plus faible l'emporte.
    labelk=sort(label[order(D)][1:k])
#on d�compte le nombre de chaque label et on prend le plus représenté
    labelk[order((table(labelk)),decreasing=TRUE)[1]]
}

