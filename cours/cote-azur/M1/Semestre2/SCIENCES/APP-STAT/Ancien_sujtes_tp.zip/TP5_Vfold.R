#commencer par charger les fonctions pr�c�dentes
# ATTENTION : J'AI MODIFIE LES FICHIERS PRECEDENTS SUR MOODL!!

source("TP4_histo_boxplot.R")
source("Generation donnees.R")

#### V-FOLD ####
#Premiere fonction : calcul de l'erreur

CalculErreurVFold=function(Data,k,v){
	NbData=nrow(Data) 			#Nombre de donnees
	NbCol=ncol(Data)				#Nombre de colonnes
	NbSubData=floor(NbData/v)		#nombre de donnees dans chaque sous echantillon (sauf le dernier)
	Data=Data[sample(1:NbData,NbData),] #m�lange de l'�chantillon
	ERROR=rep(0,v) 				#pour rentrer les erreurs sous echantillon
	for(i in (1:(v-1))) 			#Pour les v-1 premiers morceaux
		{
		indices=((i-1)*NbSubData+1):(i*NbSubData)	#les indices des donnees a selectionner 
		DataAppr=Data[indices,]		#echantillon de validation = ieme paquet
	 	DataTest=Data[-indices,]	#echantillon d'apprentissage = tout sauf ieme paquet
		donnees=DataTest[,-NbCol]	#On reprend le calcul d'erreur comme dans le hold out
 		label=DataTest[,NbCol]
  		resultats=apply(donnees,1,knn,ech=DataAppr,k=k)
  		ERROR[i]=mean(resultats!=label)
		}
	indices=((v-1)*NbSubData+1):NbData 	#Pour le dernier paquet (peut etre plus grand que les autres)	
	DataAppr=Data[indices,]			#on refait pareil que dans la boucle
	DataTest=Data[-indices,]
	donnees=DataTest[,-NbCol]	
 	label=DataTest[,NbCol]  	
	resultats=apply(donnees,1,knn,ech=DataAppr,k=k)
  	ERROR[v]=mean(resultats!=label)
	return(mean(ERROR))
}

#Deuxieme fonction : selection du meilleur K
MeilleurKVFold=function(Data,v=5,vectk=2:floor(nrow(Data)/v)){
	erreur=sapply(vectk,CalculErreurVFold,Data=Data,v=v)
	vectk[which.min(erreur)]
}

##### Evaluation de l'erreur ####
#Premiere fonction pour simplifier l'evaluation de l'erreur finale
CalculErreurFinal=function(DataAppr,DataTest,k){
	donnees=DataTest[,-ncol(DataTest)]
	label=DataTest[,ncol(DataTest)]
	resultats=apply(donnees,1,knn,ech=DataAppr,k=k)
	mean(label!=resultats)
}


#On va comparer les erreurs de Hold out de de differents vfold
#Parametres de la fonction :
#	Nbdata le nombre de donnees
#	NbIter le nombre de r�p�titions
#	ProportionAppr les differentes proportions de donnees gardees pour l'echantillon d'apprentissage (on en deduira le v)

Evaluate=function(NbData=100,NbDataFinal=500,NbIter=50,proportionAppr=c(0.5,0.66,0.8)){
#on commence par calculer les v correspondant au proportions du Hold out
	v=sort(round(1/(1-proportionAppr)))
#on va ranger les resultats dans des matrices donc les premieres colonnes seront pour les HO, et les dernieres pour les VFold
	SelectedK=matrix(0,nrow=NbIter,ncol=(length(proportionAppr)+length(v)))
	Error=SelectedK
#Simulation du jeu de donnees servant � l'evaluation
	FinalData=simulnormb(NbDataFinal,sd=2.5)
#Boucle sur les iterations (celle qui sera paralellisable)
	for(i in 1:NbIter)
		{
#on simule un jeu de donnees
		Data=simulnormb(NbData,sd=2)
#on selectionne les meilleurs k
		SelectedHO=sapply(proportionAppr,MeilleurK,Data=Data)
		SelectedVfold=sapply(v,MeilleurKVFold,Data=Data)
		SelectedK[i,]=c(SelectedHO,SelectedVfold)
#on calculr les erreurs finales associees au differents k choisis
		Error[i,]=sapply(c(SelectedHO,SelectedVfold),CalculErreurFinal,DataAppr=Data,DataTest=FinalData)
		print(paste(100*i/NbIter,"Percent Done"))
		}
#on renomme les colonnes des matrices
	colnames(SelectedK)=c(paste("HoldOut",proportionAppr),paste(v,"fold"))
	colnames(Error)=c(paste("HoldOut",proportionAppr),paste(v,"fold"))
	return(list(SelectedK=SelectedK,Error=Error))
	
}
