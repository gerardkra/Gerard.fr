#On commence par charger les fonctions pr�c�dentes
# pensz � enlever des codes d'avant les lancements de calculs

source("TP2_multilabel.R")


#Calcul de l'erreur sans data spliting

CalculErreur=function(Data,k,m=0.8){
  nbcol=ncol(Data)
  donnees=Data[,-nbcol]
  label=Data[,nbcol]
  resultats=apply(donnees,1,knn,ech=Data,k=k)
  mean(resultats!=label)
}

#Calcul de l'erreur avec data spliting (Hold Out)
CalculErreurHO=function(Data,k,m=0.8){
  nbdata=nrow(Data)
  nbappr=round(m*nbdata)
  v=sample(1:nbdata,nbappr,replace=FALSE)
  DataAppr=Data[v,]
  DataTest=Data[-v,]
  nbcol=ncol(Data)
  donnees=DataTest[,-nbcol]
  label=DataTest[,nbcol]
  resultats=apply(donnees,1,knn,ech=DataAppr,k=k)
  mean(resultats!=label)
}


#Selection du meilleur k (avec Hold Out)
MeilleurK=function(Data,m=0.8,vectk=2:floor(m*nrow(Data))){
  erreur=sapply(vectk,CalculErreurHO,Data=Data)
  vectk[which.min(erreur)]
}
