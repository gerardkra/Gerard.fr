#On commence par charger les fonctions pr�c�dentes
# pensz � enlever des codes d'avant les lancements de calculs

source("TP3 select_k.R")

#
Evaluation_selectk=function(Nobs=200,Nbiter=50,m=c(0.2,0.4,0.6,0.8)){
	K=matrix(0,nrow=Nbiter,ncol=length(m))
	Erreur=matrix(0,nrow=Nbiter,ncol=length(m))
   	data=Simulnor(Nobs)
#on melange les donnees
	data=data[sample(1:nrow(data),nrow(data)),]
	for(i in 1:length(m))
		{
  		for(j in 1:Nbiter)
			{
#on defini le vecteur des k. Ici de 2 � racine du nombre de donnees d'apprentissage
    			vectk=2:(2*sqrt(m[i]*nrow(data)))
#on choisi le meilleur k
			kopt=MeilleurK(data,m=m[i],vectk=vectk)
    			K[j,i]=kopt
#j'evalue l'erreur avec ce k selectionn�. On utilise le premier jeu de donn�es pour construire l'estimateur
# et un nouveau jeu de donn�es pour evaluer l'erreur
			data2=Simulnor(Nobs)
			donnees=data2[,-ncol(data2)]
			label=data2[,ncol(data2)]
			result=apply(donnees,1,knn,k=kopt,ech=data)
			Erreur[j,i]=mean(result!=label)
  			}
		print(paste("i=",i,"sur",length(m)))
		}
#Je renomme les colonnes des deux matrices
	colnames(K)=paste("m = ",m)
	colnames(Erreur)=paste("m = ",m)
	return(list(K=K,Erreur=Erreur))
}

#result=Evaluation_selectk(Nobs=50,Nbiter=100)
#K=result$K
#Erreur=result$Erreur

##################
####Graphiques####
##################


##############
#Histogrammes#
##############
#par(mfrow=c(2,2))
#m=c(0.2,0.4,0.6,0.8)
#for(i in 1:4){hist(K[,i],freq=FALSE,xlab="kstar",main=paste("histograme des k selectiones pour m =",m[i]))}

#########
#Boxplot#
#########
#par(mfrow=c(1,2))
#boxplot(K,main="r�partition des k choisis")
#boxplot(Erreur,main="r�partition des erreurs obtenues")
