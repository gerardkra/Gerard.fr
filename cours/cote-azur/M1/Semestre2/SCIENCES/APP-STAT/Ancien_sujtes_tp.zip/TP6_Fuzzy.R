source("Generation donnees.R")

###norme euclidienne### 

NormEucl=function(x){sqrt(sum(x^2))}

##################
### Fuzzy knn ####
##################

## Creation de U##
createU=function(Data){
	Nbcol=ncol(Data)
	NbData=nrow(Data)
	Data=Data[order(Data[,Nbcol]),]
	label=Data[,Nbcol]
	uniquelabel=unique(label)
	Nblabel=length(uniquelabel)
	U=matrix(0,ncol=NbData,nrow=Nblabel)
	for (i in 1:Nblabel)
		{
		U[i,]=as.numeric(label==uniquelabel[i])
		}
	return(U)
}

## Fonction de classification ##

Fuzzyknn=function(x,Data,k,gamma,U=0){
	Nbcol=ncol(Data)
	NbData=nrow(Data)
	Data=Data[order(Data[,Nbcol]),]
	donnees=Data[,-Nbcol]
	label=Data[,Nbcol]
	uniquelabel=unique(label)
	Nblabel=length(uniquelabel)
#U doit etre une matrice qui peut etre donnee comme argument.
#si on ne renseigne pas U, il vaut 0 par defaut et il faut creer la matrice 
	if(is.numeric(U)){U=createU(Data)}
#Distances a x
	D=apply(donnees-matrix(rep(x,NbData),ncol=(Nbcol-1),byrow=TRUE),1,NormEucl)
	ODk=order(D)[1:k]
	app=rep(0,Nblabel)
	for (i in 1:Nblabel)
		{
		app[i]=sum(U[i,ODk]/(D[ODk]^(2/(gamma-1))))/sum(1/(D[ODk]^(2/(gamma-1))))
		}
	return(app)
}

## fonction Harden
Harden=function(Uf){apply(Uf,2,function(x){as.numeric(x==max(x))})}

## Exemple ##
#Data=simulnormb(nbdata=1000)
#U=createU(Data)
#Datanew=simulnormb(nbdata=1000)
#Datanew=Datanew[order(Datanew[,ncol(Datanew)]),]
#donnees=Datanew[,-ncol(Datanew)]
#label=Datanew[,ncol(Datanew)]
#fuzzypred=apply(donnees,1,Fuzzyknn,Data=Data,k=40,gamma=4,U=U)
#hardpred=apply(donnees,1,Fuzzyknn,Data=Data,k=40,gamma=1.05,U=U)
#Unew=createU(Datanew)
#print(paste("erreur de classification hard",sum(Harden(hardpred)!=Unew)/(2*ncol(Unew))))
#print(paste("erreur de classification fuzzy",sum(Harden(fuzzypred)!=Unew)/(2*ncol(Unew))))


	