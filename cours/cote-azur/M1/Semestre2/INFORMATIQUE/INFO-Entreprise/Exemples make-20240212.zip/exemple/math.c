#include "math.h"

double puissance (int a, int b) {
    double z = 1.0;
    while (b > 0) {
        z *= a;
        b--;
    }
    return z;
}
