
/* Retourne a^b (ou 1.0 si b < 0) */
double puissance (int , int);
