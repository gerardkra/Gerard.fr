#include <iostream>

int main(int argc, char *argv[])
{
#ifdef __GNUC__
  std::cout << "Version de gcc : " << __GNUC__ << "." << __GNUC_MINOR__ << "\n";
#endif
  std::cout << "Bonjour ";
  if (argc > 1)
  {
    std::cout << argv[1];
  }
  std::cout << "\n";
  return 0;
}